function Throttle = Throttle(v)
persistent state; % Cria uma memória para o bloco
    if isempty(state)
        state = 0; % Começa desligado
    end

    if v < 6.94        % 25 km/h em m/s
    state = 1;
    elseif v > 9.722  % 35 km/h em m/s
    state = 0;
    end
    Throttle = state;
end