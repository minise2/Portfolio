function plot_lap_telemetry(x, y, s, v, ay_vec, Tx_vec, Ty_vec)
% PLOT_LAP_TELEMETRY  Interactive telemetry with slider + timer animation
%                     Full lap animation always takes 10 seconds (x1 speed)
%
%   plot_lap_telemetry(x, y, s, v, ay_vec, Tx_vec, Ty_vec)

N     = length(x);
v_kmh = v * 3.6;

%% ── ANIMATION CONSTANTS ──────────────────────────────────────────────────
LAP_DURATION = 10.0;   % seconds for one full lap at 1x speed
FPS          = 30;     % frames per second
N_FRAMES     = round(FPS * LAP_DURATION);   % = 300 frames total at 1x

% Pre-compute which track index corresponds to each animation frame
% Evenly spaced in distance along the lap
frame_indices = round(linspace(1, N-1, N_FRAMES));

%% ── SHARED STATE ─────────────────────────────────────────────────────────
current_frame = 1;
anim_timer    = [];

%% ── FIGURE ───────────────────────────────────────────────────────────────
fig = figure('Name', 'Lap Telemetry', ...
             'Color',            [0.08 0.09 0.11], ...
             'Position',         [100 60 1300 760], ...
             'NumberTitle',      'off', ...
             'CloseRequestFcn',  @on_close);

%% ── TRACK MAP (left) ─────────────────────────────────────────────────────
ax_track = subplot('Position', [0.03 0.14 0.42 0.82]);
set(ax_track, 'Color',     [0.10 0.12 0.15], ...
              'XColor',    [0.35 0.40 0.46], ...
              'YColor',    [0.35 0.40 0.46], ...
              'GridColor', [0.20 0.24 0.30], ...
              'GridAlpha', 1, 'FontSize', 9);
grid(ax_track, 'on'); hold(ax_track, 'on'); axis(ax_track, 'equal');
xlabel(ax_track, 'X (m)', 'Color', [0.55 0.60 0.65]);
ylabel(ax_track, 'Y (m)', 'Color', [0.55 0.60 0.65]);
title(ax_track, 'Track — Estoril', ...
      'Color', [0.85 0.88 0.92], 'FontWeight', 'normal', 'FontSize', 11);

% Track coloured by speed
cmap  = jet(256);
v_min = min(v_kmh); v_max = max(v_kmh);
for i = 1:N-1
    ci = round(1 + 255*(v_kmh(i)-v_min) / max(v_max-v_min, 1));
    ci = min(max(ci,1), 256);
    plot(ax_track, x(i:i+1), y(i:i+1), '-', ...
         'Color', cmap(ci,:), 'LineWidth', 2.5);
end

cb = colorbar(ax_track, 'Location', 'southoutside');
colormap(ax_track, jet);
caxis(ax_track, [v_min v_max]);
cb.Color = [0.55 0.60 0.65];
cb.Label.String = 'Speed (km/h)';
cb.Label.Color  = [0.55 0.60 0.65];
cb.FontSize = 8;

plot(ax_track, x(1), y(1), 's', 'MarkerSize', 10, ...
     'MarkerFaceColor', [0.3 0.9 0.5], 'MarkerEdgeColor', 'none');
text(ax_track, x(1)+3, y(1)+3, 'START', ...
     'Color', [0.3 0.9 0.5], 'FontSize', 8);

h_car = plot(ax_track, x(1), y(1), 'o', ...
             'MarkerSize',      13, ...
             'MarkerFaceColor', [0.95 0.15 0.15], ...
             'MarkerEdgeColor', [1 1 1], ...
             'LineWidth',       1.5);

h_info = text(ax_track, x(1)+4, y(1)+4, '', ...
              'Color', [0.95 0.15 0.15], 'FontSize', 8, 'FontWeight', 'bold');

%% ── TELEMETRY PANELS (right) ─────────────────────────────────────────────
right_x = 0.54;
right_w = 0.44;
panel_h = 0.25;
tops    = [0.68, 0.39, 0.10];

colors = {[1.00 0.85 0.20],
          [1.0  0.42 0.20],
          [0.50 1.00 0.42]};

titles = {'Speed  v  (km/h)', ...
          'Longitudinal load transfer  Tx  (N)', ...
          'Lateral load transfer  Ty  (N)'};

data  = {v_kmh, Tx_vec, Ty_vec};
units = {'km/h', 'N', 'N'};

ax_tel  = gobjects(3,1);
h_dot   = gobjects(3,1);
h_vline = gobjects(3,1);
h_val   = gobjects(3,1);

for k = 1:3
    d = data{k};
    ax_tel(k) = subplot('Position', [right_x, tops(k), right_w, panel_h]);
    set(ax_tel(k), ...
        'Color',     [0.10 0.12 0.15], ...
        'XColor',    [0.35 0.40 0.46], ...
        'YColor',    [0.35 0.40 0.46], ...
        'GridColor', [0.20 0.24 0.30], ...
        'GridAlpha', 1, 'FontSize', 8, ...
        'XLim', [0 s(end)], ...
        'YLim', [min(d)*1.2 - 0.1, max(d)*1.2 + 0.1]);
    grid(ax_tel(k), 'on'); hold(ax_tel(k), 'on');
    xlabel(ax_tel(k), 'Distance (m)', 'Color', [0.55 0.60 0.65]);
    title(ax_tel(k), titles{k}, ...
          'Color', colors{k}, 'FontWeight', 'normal', 'FontSize', 9);

    yline(ax_tel(k), 0, 'Color', [0.30 0.35 0.40], 'LineWidth', 0.8);

    plot(ax_tel(k), s(1:end-1), d(1:end-1), ...
         'Color', colors{k}, 'LineWidth', 1.5);

    yl = get(ax_tel(k), 'YLim');
    h_vline(k) = plot(ax_tel(k), [s(1) s(1)], yl, '--', ...
                      'Color', [0.9 0.9 0.9], 'LineWidth', 1);

    h_dot(k) = plot(ax_tel(k), s(1), d(1), 'o', ...
                    'MarkerSize',      9, ...
                    'MarkerFaceColor', colors{k}, ...
                    'MarkerEdgeColor', [1 1 1], ...
                    'LineWidth',       1.2);

    xl = get(ax_tel(k), 'XLim');
    yl = get(ax_tel(k), 'YLim');
    h_val(k) = text(ax_tel(k), xl(2)*0.97, yl(2)*0.88, ...
                    sprintf('%.2f %s', d(1), units{k}), ...
                    'Color', colors{k}, 'FontSize', 12, ...
                    'FontWeight', 'bold', 'HorizontalAlignment', 'right');
end

%% ── CONTROLS ─────────────────────────────────────────────────────────────
% Play / Pause button
btn_play = uicontrol('Style',    'pushbutton', ...
    'Units',           'normalized', ...
    'Position',        [0.03 0.060 0.07 0.038], ...
    'String',          '▶  Play', ...
    'BackgroundColor', [0.15 0.65 0.35], ...
    'ForegroundColor', [1 1 1], ...
    'FontSize',        9, ...
    'FontWeight',      'bold', ...
    'Callback',        @toggle_play);

% Speed label
uicontrol('Style', 'text', ...
    'Units',           'normalized', ...
    'Position',        [0.11 0.060 0.07 0.030], ...
    'String',          'Speed:', ...
    'BackgroundColor', [0.08 0.09 0.11], ...
    'ForegroundColor', [0.55 0.60 0.65], ...
    'FontSize',        8);

% Speed popup — multiplies FPS, so 2x = 20s lap becomes 5s
speed_popup = uicontrol('Style', 'popupmenu', ...
    'Units',           'normalized', ...
    'Position',        [0.17 0.062 0.07 0.032], ...
    'String',          {'0.25x','0.5x','1x','2x','4x'}, ...
    'Value',           3, ...
    'BackgroundColor', [0.18 0.22 0.28], ...
    'ForegroundColor', [0.85 0.88 0.92], ...
    'FontSize',        8);

% Slider label
uicontrol('Style', 'text', ...
    'Units',           'normalized', ...
    'Position',        [0.03 0.022 0.10 0.020], ...
    'String',          'Lap position:', ...
    'BackgroundColor', [0.08 0.09 0.11], ...
    'ForegroundColor', [0.55 0.60 0.65], ...
    'FontSize',        8, ...
    'HorizontalAlignment', 'left');

% Slider
slider = uicontrol('Style', 'slider', ...
    'Units',      'normalized', ...
    'Position',   [0.13 0.022 0.84 0.030], ...
    'Min',        1, 'Max', N_FRAMES, 'Value', 1, ...
    'SliderStep', [1/(N_FRAMES-1), 10/(N_FRAMES-1)], ...
    'BackgroundColor', [0.18 0.22 0.28], ...
    'Callback',   @on_slider);

addlistener(slider, 'Value', 'PostSet', @(~,~) on_slider([], []));

%% ── UPDATE DISPLAY ───────────────────────────────────────────────────────
    function update_display(frame)
        frame = max(1, min(frame, N_FRAMES));
        i     = frame_indices(frame);

        set(h_car,  'XData', x(i), 'YData', y(i));
        set(h_info, 'Position', [x(i)+4, y(i)+4, 0], ...
                    'String', sprintf('%.0f m  |  %.1f km/h', s(i), v_kmh(i)));

        for k = 1:3
            d = data{k};
            set(h_vline(k), 'XData', [s(i) s(i)]);
            set(h_dot(k),   'XData', s(i), 'YData', d(i));
            set(h_val(k),   'String', sprintf('%.2f %s', d(i), units{k}));
        end

        set(slider, 'Value', frame);
        drawnow limitrate
    end

%% ── SLIDER CALLBACK ──────────────────────────────────────────────────────
    function on_slider(~, ~)
        if isempty(anim_timer) || strcmp(get(anim_timer,'Running'), 'off')
            current_frame = round(get(slider, 'Value'));
            update_display(current_frame);
        end
    end

%% ── PLAY / PAUSE CALLBACK ────────────────────────────────────────────────
    function toggle_play(~, ~)
        if ~isempty(anim_timer) && isvalid(anim_timer) && ...
                strcmp(get(anim_timer, 'Running'), 'on')
            % --- PAUSE ---
            stop(anim_timer);
            set(btn_play, 'String', '▶  Play', ...
                          'BackgroundColor', [0.15 0.65 0.35]);
        else
            % --- PLAY ---
            if current_frame >= N_FRAMES
                current_frame = 1;   % restart from beginning
            end
            set(btn_play, 'String', '⏸  Pause', ...
                          'BackgroundColor', [0.75 0.30 0.15]);
            start_timer();
        end
    end

%% ── TIMER-BASED ANIMATION ────────────────────────────────────────────────
    function start_timer()
        speed_vals = [0.25, 0.5, 1.0, 2.0, 4.0];
        spd        = speed_vals(get(speed_popup, 'Value'));

        % Period = time between frames
        % At 1x: LAP_DURATION/N_FRAMES = 10/300 = 0.0333s per frame = 30 FPS
        period = LAP_DURATION / (N_FRAMES * spd);
        period = max(period, 0.01);   % floor at 100 FPS to avoid overload

        if ~isempty(anim_timer) && isvalid(anim_timer)
            delete(anim_timer);
        end

        anim_timer = timer(...
            'ExecutionMode', 'fixedRate', ...
            'Period',        period, ...
            'TimerFcn',      @timer_step, ...
            'StopFcn',       @timer_stopped);

        start(anim_timer);
    end

    function timer_step(~, ~)
        if ~ishandle(fig)
            stop(anim_timer); return
        end
        current_frame = current_frame + 1;
        if current_frame >= N_FRAMES
            current_frame = N_FRAMES;
            update_display(current_frame);
            stop(anim_timer);
        else
            update_display(current_frame);
        end
    end

    function timer_stopped(~, ~)
        if ishandle(fig)
            set(btn_play, 'String', '▶  Play', ...
                          'BackgroundColor', [0.15 0.65 0.35]);
        end
    end

%% ── CLOSE HANDLER ────────────────────────────────────────────────────────
    function on_close(~, ~)
        if ~isempty(anim_timer) && isvalid(anim_timer)
            stop(anim_timer);
            delete(anim_timer);
        end
        delete(fig);
    end

%% ── INITIAL DRAW ─────────────────────────────────────────────────────────
update_display(1);

end