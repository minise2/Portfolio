% This code has the objective of simulating a car going around a track
% while taking into acount the logitudunal and lateral weight tranfers 
% outputing the telemetry of the car around the track

% -- DATA ---------------------------------------------------
m    = 177;     % kg
rho  = 1.225;   % kg/m^3
A    = 2.2;     % m^2
C_d  = 0.08;
C_rr = 0.00904;
Wb   = 1.55;    % m
T    = 1.11;    % m     
Iz   = 57.21;   % kg*m^2
CG   = 0.4;     % m
g    = 9.81;    % m/s^2  
    
% -- TRACK ---------------------------------------------------
run('estoril_track.m')
track = flipud(track);
x = track(:,1);
y = track(:,2);
N = length(x);

% Cumulative distance
dx = diff(x);
dy = diff(y);
ds = sqrt(dx.^2 + dy.^2);
s  = [0; cumsum(ds)];

% -- VECTORS ---------------------------------------------------
v      = zeros(N, 1);
ax_vec = zeros(N, 1);
ay_vec = zeros(N, 1);
Tx_vec = zeros(N, 1);   % longitudinal load transfer
Ty_vec = zeros(N, 1);   % lateral load transfer
m_Fl_vec   = zeros(N, 1);      
m_Fr_vec   = zeros(N, 1);      
m_Rl_vec   = zeros(N, 1);      
m_Rr_vec   = zeros(N, 1);

v(1) = 9.722;     % m/s
m_Fl_1 = 35;      % kg
m_Fr_1 = 39;      % kg
m_Rl_1 = 54;      % kg
m_Rr_1 = 49;      % kg

% -- CURVATURE ---------------------------------------------------
R = zeros(N, 1);
R(1)   = inf;    % straight at endpoints
R(end) = inf;
for i = 2:N-1
    dir1x = x(i)   - x(i-1);
    dir1y = y(i)   - y(i-1);
    
    % Vector from current to next point
    dir2x = x(i+1) - x(i);
    dir2y = y(i+1) - y(i);
    
    % 2D cross product — gives the turn direction
    cross_z = dir1x*dir2y - dir1y*dir2x;
    
    % Sign: positive = left turn, negative = right turn
    turn_sign(i) = sign(cross_z);

    a    = sqrt((x(i)-x(i-1))^2 + (y(i)-y(i-1))^2);
    b    = sqrt((x(i+1)-x(i))^2 + (y(i+1)-y(i))^2);
    c    = sqrt((x(i+1)-x(i-1))^2 + (y(i+1)-y(i-1))^2);
    area = abs(x(i-1)*(y(i)-y(i+1)) + ...
               x(i)*(y(i+1)-y(i-1)) + ...
               x(i+1)*(y(i-1)-y(i)));
    
    if area < 20         % tolerance
        R(i) = inf;
    else
        R(i) = (a * b * c) / area;
    end
end

turn_sign(1)   = turn_sign(2);
turn_sign(end) = turn_sign(end-1);

% -- VELOCITY LOOP ---------------------------------------------------
for i = 1:N-1

    % --- Forces at current velocity ---
    F_aero = 0.5 * rho * C_d * A * v(i)^2;
    F_rr   = C_rr * m * g;
    F_neg  = F_aero + F_rr;

    % --- Throttle decision ---
    if Throttle(v(i)) == 1
        ax_drive = 0.5;    % m/s^2 If ax_drive is to high the sistem wont be able to regulate a vmax of 35km/h because afther a step is already 40 km/h
    else
        ax_drive = 0;
    end
    

    % --- Longitudinal acceleration ---
    ax = ax_drive - F_neg / m;

    % --- Lateral acceleration ---
    if R(i) == inf
        ay = 0;
    else
        ay = turn_sign(i)*v(i)^2 / R(i);
    end

    % --- Load transfers ---
    Tx = (m * ax * CG) / T;    % longitudinal
    Ty = (m * ay * CG) / Wb;   % lateral

    % --- Tyre Loads ---
    m_Fl = m_Fl_1 + Tx/(2*g) - Ty/(2*g);
    m_Fr = m_Fr_1 + Tx/(2*g) + Ty/(2*g);
    m_Rl = m_Rl_1 - Tx/(2*g) - Ty/(2*g);
    m_Rr = m_Rr_1 - Tx/(2*g) + Ty/(2*g);

    % --- Integrate velocity (Euler step) ---
    dt     = ds(i) / v(i);      % time for this segment
    v(i+1) = v(i) + ax * dt;

    % --- Clamp velocity ---
    v(i+1) = max(v(i+1), 0.1);
    v(i+1) = min(v(i+1), 11.11);


    % --- Store results ---
    ax_vec(i) = ax;
    ay_vec(i) = ay;
    Tx_vec(i) = Tx;
    Ty_vec(i) = Ty;
    m_Fl_vec(i)   = m_Fl ;      
    m_Fr_vec(i)   = m_Fr ;      
    m_Rl_vec(i)   = m_Rl ;      
    m_Rr_vec(i)   = m_Rr ;

end

% -- RESULTS ---------------------------------------------------
figure;
subplot(2,2,1); plot(s, v*3.6);       xlabel('Distance (m)'); ylabel('Speed (km/h)');  title('Speed profile');
subplot(2,2,2); plot(s, ay_vec);      xlabel('Distance (m)'); ylabel('ay (m/s²)');     title('Lateral acceleration');
subplot(2,2,3); plot(s, Tx_vec);      xlabel('Distance (m)'); ylabel('Transfer (N)');  title('Long. load transfer');
subplot(2,2,4); plot(s, Ty_vec);      xlabel('Distance (m)'); ylabel('Transfer (N)');  title('Lat. load transfer');

figure;
subplot(2,2,1); plot(s, m_Fl_vec);       xlabel('Distance (m)'); ylabel('Fl load'); title('Load profile Fl');
subplot(2,2,2); plot(s, m_Fr_vec);      xlabel('Distance (m)'); ylabel('Fr load');  title('Load profile Fr');
subplot(2,2,3); plot(s, m_Rl_vec);      xlabel('Distance (m)'); ylabel('Rl load');  title('Load profile Rl');
subplot(2,2,4); plot(s, m_Rr_vec);      xlabel('Distance (m)'); ylabel('Rr load');  title('Load profile Rr');

figure;
plot(s,ax_vec);

plot_lap_telemetry(x, y, s, v, ay_vec, Tx_vec, Ty_vec);